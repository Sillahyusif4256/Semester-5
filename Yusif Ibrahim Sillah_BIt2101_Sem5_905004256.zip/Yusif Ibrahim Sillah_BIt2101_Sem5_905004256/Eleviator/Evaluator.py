import operator
import os

# 1. STACK HANDLER FUNCTIONS (Requirement B. 1)

def create_stack():
    """Initializes an empty list to act as a stack."""
    return []


def is_empty(stack):
    """Checks if the stack is empty."""
    return len(stack) == 0


def push(stack, item):
    """Adds an item to the top of the stack (PUSH)."""
    stack.append(item)


def pop(stack):
    """Removes and returns the item from the top of the stack (POP)."""
    if is_empty(stack):
        raise IndexError("POP from an empty stack")
    return stack.pop()


def peek(stack):
    """Returns the item at the top without removing it (PEEK)."""
    if is_empty(stack):
        return None
    return stack[-1]


# 2. OPERATOR PRECEDENCE AND UTILITIES

# Define precedence for operators: Higher number means higher precedence
_precedence = {'+': 1, '-': 1, '*': 2, '/': 2, '^': 3}

# Define built-in operator functions for calculation
_operators = {
    '+': operator.add,
    '-': operator.sub,
    '*': operator.mul,
    '/': operator.truediv
}


def is_operator(token):
    """Checks if a token is a valid operator."""
    return token in _operators


def get_precedence(token):
    """Returns the precedence level of an operator."""
    # '^' is handled implicitly by Shunting-Yard, but included here for completeness
    return _precedence.get(token, 0)



# 3. CORE LOGIC: INFIX TO POSTFIX CONVERSION (Shunting-Yard)


def infix_to_postfix(tokens):
    """
    Converts a list of infix tokens (expression) into a list of postfix tokens.
    Uses the Shunting-Yard algorithm.
    """
    op_stack = create_stack()
    postfix_output = []

    for token in tokens:
        try:
            # 1. Operand (Number)
            float(token)
            postfix_output.append(token)
        except ValueError:
            # 2. Operator or Parenthesis
            if token == '(':
                push(op_stack, token)
            elif token == ')':
                # Pop operators until the matching '(' is found
                while not is_empty(op_stack) and peek(op_stack) != '(':
                    postfix_output.append(pop(op_stack))
                if not is_empty(op_stack) and peek(op_stack) == '(':
                    pop(op_stack)  # Discard the '('
                else:
                    raise ValueError("Mismatched parentheses")
            elif is_operator(token):
                # Pop operators with higher or equal precedence
                while (not is_empty(op_stack) and peek(op_stack) != '(' and
                       get_precedence(peek(op_stack)) >= get_precedence(token)):
                    postfix_output.append(pop(op_stack))
                push(op_stack, token)
            else:
                # Handle unknown token (optional, but good practice)
                raise ValueError(f"Unknown token: {token}")

    # Pop any remaining operators from the stack
    while not is_empty(op_stack):
        if peek(op_stack) == '(':
            raise ValueError("Mismatched parentheses")
        postfix_output.append(pop(op_stack))

    return postfix_output



# 4. CORE LOGIC: POSTFIX EVALUATION (Requirement B. 2)


def evaluate_postfix(postfix_tokens):
    """
    Evaluates a postfix expression using a stack.
    """
    operand_stack = create_stack()

    for token in postfix_tokens:
        try:
            # 1. Operand (Number)
            push(operand_stack, float(token))
        except ValueError:
            # 2. Operator
            if is_operator(token):
                if len(operand_stack) < 2:
                    raise ValueError("Insufficient operands for operator " + token)

                # Operands are popped in reverse order: Operand 2, then Operand 1
                operand2 = pop(operand_stack)
                operand1 = pop(operand_stack)

                if token == '/' and operand2 == 0:
                    raise ZeroDivisionError("Division by zero")

                # Perform the operation and push the result
                result = _operators[token](operand1, operand2)
                push(operand_stack, result)
            else:
                raise ValueError(f"Unexpected token in postfix: {token}")

    # The final result should be the only item left on the stack
    if len(operand_stack) == 1:
        return pop(operand_stack)
    else:
        # Handles cases like an expression missing operators (e.g., "5 4")
        raise ValueError("Too many operands left on stack")


# 5. FILE HANDLING AND MAIN EXECUTION (Requirements 2 & D)

INPUT_FILE = "input.txt"
OUTPUT_FILE = "output.txt"


def create_sample_input(file_name):
    """
    Creates a sample input file with 6 expressions for demonstration.
    """
    sample_expressions = [
        # 1. Simple addition
        "10 + 5",
        # 2. Order of operations
        "3 * ( 4 + 2 )",
        # 3. Complex expression with division and subtraction
        "( 10 - 2 ) * 5 / 4",
        # 4. Expression resulting in float
        "15 / 2 + 1",
        # 5. Invalid: Mismatched parentheses (should result in ERROR)
        "4 + ( 3 * 2",
        # 6. Invalid: Division by zero (should result in ERROR)
        "10 / ( 5 - 5 )"
    ]
    try:
        with open(file_name, 'w') as f:
            for expr in sample_expressions:
                f.write(expr + "\n")
        print(f"Created sample input file: '{file_name}' with 6 expressions.")
    except Exception as e:
        print(f"Error creating sample input file: {e}")


def read_input_expressions(file_name):
    """Reads expressions from the input file."""
    expressions = []
    try:
        with open(file_name, 'r') as f:
            for line in f:
                # Split the line by spaces and filter empty strings
                tokens = [token for token in line.strip().split() if token]
                if tokens:
                    expressions.append(tokens)
    except FileNotFoundError:
        print(f"Error: Input file '{file_name}' not found.")
        return None
    return expressions


def write_results(file_name, results):
    """Writes the evaluated results to the output file."""
    try:
        with open(file_name, 'w') as f:
            for result in results:
                # Formatting the output: integers are written as integers, others as strings
                if isinstance(result, float) and result.is_integer():
                    f.write(f"{int(result)}\n")
                else:
                    f.write(f"{result}\n")
        print(f"Successful: Results written to '{file_name}'")
    except Exception as e:
        print(f"Error writing to output file: {e}")


def main():
    """Main function to orchestrate the reading, evaluation, and writing process."""
    # Ensure a sample input file exists for demonstration
    if not os.path.exists(INPUT_FILE):
        create_sample_input(INPUT_FILE)

    expressions = read_input_expressions(INPUT_FILE)
    if not expressions:
        return

    results = []

    # Process each expression
    for tokens in expressions:
        try:
            # Step 1: Convert Infix to Postfix
            postfix_tokens = infix_to_postfix(tokens)
            # Step 2: Evaluate Postfix
            result = evaluate_postfix(postfix_tokens)
            results.append(result)
        except (ValueError, ZeroDivisionError) as e:
            # Catch evaluation errors (e.g., mismatched parentheses, division by zero)
            results.append(f"ERROR: {e}")
        except IndexError as e:
            # Catch stack-related errors, usually due to malformed expression
            results.append(f"ERROR: Malformed expression ({e})")

    # Write all calculated results (or errors) to the output file
    write_results(OUTPUT_FILE, results)


if __name__ == "__main__":
    main()